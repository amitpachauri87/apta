﻿=== Plugin Name ===

Contributors:      (CIS Team)
Plugin Name:       (Block Widget)
Plugin URI:        (https://www.cisin.com)
Tags:              (posttype blocks in sidebar)
Author URI:        (https://www.cisin.com)
Author:            (CIS Team)
Donate link:       (https://www.paypal.me/cyberinfrastructure)
Requires at least: (4.0) 
Tested up to:      (5.0)
Stable tag:        (1.0)
Version:           (1.0)

== Description ==
This is the custom plugin created for creating sidebar widgets based on the custom post type. In the widget blocks CPT you will be able to create multiple blocks widget and after creating them you will be able to assign in the widget section where we have created widget for widget block assign into it and show it on front end.
== Installation ==
Download the plugin upload it to the wordpress plugins folder and create your block widgets after that assign them in the widget section

== Upgrade Notice ==
We will try to improve the plugin time to time

== Screenshots ==

== Changelog ==

== Frequently Asked Questions ==

1. Is that plugin used in any of the site?
 Yes you will be able to use this plugin in any of the wordpress website and create your sidebar interactive

== Donations ==

